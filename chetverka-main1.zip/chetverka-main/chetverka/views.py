from django.shortcuts import render
from chetverka.models import Ticket, PricesAndProducts, Transaction
from django.views.generic import DetailView
from chetverka.forms import bankCardForm
from teletroyka.models import TelegramUser
import re, random

def log(request):
    search_query = request.GET.get('search')
    data = Ticket.objects.all()
    if search_query == None:
        data = Ticket.objects.filter(id__in=data).order_by('id')
    elif re.match(r"\D{2,}", search_query) != None:
        data = Ticket.objects.filter(id__in=data, ticket_type__contains=search_query).order_by('-id')
    elif re.match(r"\d{10}", search_query) != None:
        data = Ticket.objects.filter(id__in=data, ticket_number__contains=search_query).order_by('-id')
    elif re.search(r"\d{1,}", search_query) != None:
        data = Ticket.objects.filter(id__in=data, id__contains=search_query).order_by('-id')
    else :
        print('Not Found')
    return render(request, 'chetverka/log.html', {'Ticket': data})


class Detalization(DetailView):
    model = Ticket
    template_name = 'chetverka/detalization.html'
    context_object_name = 'record'


def base(request):
    data = PricesAndProducts.objects.all()
    return render(request, 'chetverka/base.html', {'price': data})

class PricesAndProductsController(DetailView):
    model = PricesAndProducts
    template_name = 'base/chetverka/payform.html'
    context_object_name = 'record'
    form = bankCardForm



    def get_context_data(self, **kwargs):

        context = super(PricesAndProductsController, self).get_context_data(**kwargs)
        context['form'] = bankCardForm()
        return context

    def post(self, request, *args, **kwargs):
        user = TelegramUser.objects.get(pk=1) #ID юзера изменить!!
        if request.method == 'POST':
            form = bankCardForm(request.POST)
            if form.is_valid():
                bank_card = form.save(commit=False)
                print(bank_card)
                bank_card.telegramuser = user
                print(bank_card)
                bank_card.save()
                transact = Transaction.objects.create(tr_status='Succeed', bankcard=bank_card)
                Ticket.objects.create(ticket_type='Тройка', ticket_number=random.randint(1000000000, 9999999999), transaction=transact)
                return render(request, 'chetverka/status.html')
        else:
            form = bankCardForm(initial=user)

        return render(request, 'chetverka/base.html', {'form': form})

def test(request):
    return render(request, 'chetverka/TestView.html')

def pay(request):
    if request.method == 'POST':
        data = request.POST
        print(data)
    return render(request, 'chetverka/payform.html')