from django.apps import AppConfig


class ChetverkaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'chetverka'
