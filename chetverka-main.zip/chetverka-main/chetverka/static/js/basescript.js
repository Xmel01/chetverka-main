var counter = 0;
$(document).ready(function(){
    $('.badge').text(counter);

});

function addElement(){
    var all_counters = $("div[id^='counter']");
    var total_sum = 0;
    for (var i=0; i<all_counters.length;i++){
        let value = parseInt($(all_counters[i]).text());
        let price = parseInt($(all_counters[i]).parents(2).children('.cardTitle').text().split(' ')[2]);
        let mul = value * price;
        total_sum += mul;
    }
    $('#total').text('Всего на сумму: ' + total_sum +' ₽');
    return total_sum;
}


$(document).on('click', '[id^=cell-btn]', function() {
    counter++;
    let button_id = ($(this).attr('id')).split(' ')[1]; // получаем id нажатой кнопки "добавить"
    let card = $(this).parents(1).children('.cardTitle').text(); // даем значению card название карточки
    $(this).parent().html('<div class="row"><button class="btn btn-outline-success col-sm-4" id="plus ' + button_id +'"><span>+</span></button><button onclick="addElement()" class="btn btn-outline-danger col-sm-4" id="minus ' + button_id +'"><span>-</span></button><div class="alert-primary col-sm-4" id="counter'+ button_id + '">1</div></div>');
    $('div[rel=item-container]').prepend('<div class="alert alert-success" id="basket-item '+ button_id + '">1 ' + card + '</div>');
    $('.badge').text(counter);
    addElement();
    $('#body').append('<button class="btn-success rounded-top" onclick="payFunction()" id="payment">Оплатить</button>')
})

function payFunction(){
    let prods = $('div[rel=item-container]').children();
    for (var p=0;p<prods.length;p++){
       $('#modal-body').append(prods[p])
    }
    $('#modal').modal('show');
}

function proceed(){
    $.ajax({
            url: "payform" + row.id + "/",
            method: "patch",
            dataType: "json",
            headers: {
                'X-CSRFToken': csrftoken
            },
            data: {
                'flag': false,
            },
            success: function() {
                $table.bootstrapTable('refresh');
            }
        })
}

$(document).on('click', '[id^=plus]', function(){
    counter++;
    console.log(document.getElementById("payment"))
    console.log($("#payment"))
    let plus_id = ($(this).attr('id')).split(' ')[1];
    let count = parseInt($(this).siblings('.alert-primary').text()); // берем количество товара на карточке и переводим в Integer
    $(this).siblings('.alert-primary').text(count+1); // Прибавляем число
    let all_baskets = $('[rel="item-container"]').children();
    for (var i = 0; i < all_baskets.length; i++) {
        let basket = $(all_baskets[i]);
        if ('basket-item '+ plus_id === basket.attr('id')) {
           let string = basket.text().split(' ')[0];
           let container = basket.text().replace(string, count+1);
           basket.text(container);
           addElement();
           }
    }

     $('.badge').text(counter);// Кол-во товаров всего (иконка рядом с корзиной)
});

$(document).on('click', '[id^=minus]', function(){
    counter--;
    $('.badge').text(counter);
    let plus_id = ($(this).attr('id')).split(' ')[1];
    let count = parseInt($(this).siblings('.alert-primary').text()); // берем количество товара на карточке и переводим в Integer
    $(this).siblings('.alert-primary').text(count-1); // Прибавляем число
    let all_baskets = $('[rel="item-container"]').children();
    for (var i = 0; i < all_baskets.length; i++) {
        let basket = $(all_baskets[i]);
        if ('basket-item '+ plus_id === basket.attr('id')) {
           let string = basket.text().split(' ')[0];
           let container = basket.text().replace(string, count-1);
           if (count === 1){
               basket.remove();
           }
           else{
               basket.text(container);

           }
        }
    }
});

